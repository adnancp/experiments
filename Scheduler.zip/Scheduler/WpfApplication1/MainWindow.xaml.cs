﻿using System;
using System.Windows;
using Microsoft.Win32.TaskScheduler;
using Npgsql;
using System.Linq;
using System.Collections.Generic;
using WpfApplication1.ViewModels;

namespace WpfApplication1
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var context = new ScriptSchedulerViewModel();

            context.Settings = new SchedulerSettings();

            string connectionString = "Server=85.92.146.196;port=5432;Database=bodyview3;UserID=postgres;Password=Banek12";
            string selectQuery = "select scriptid ,scriptname from script";
            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                NpgsqlCommand commandSelect = new NpgsqlCommand(selectQuery, connection);

                // Execute the query and obtain a result set
                NpgsqlDataReader dr = commandSelect.ExecuteReader();

                // Output rows
                while (dr.Read())
                {
                    context.Scripts.Add(new ScriptItem((int)dr["scriptid"], dr["scriptname"].ToString()));
                }
            }
            DataContext = context;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            //Synchronize();
            
            SaveSchedulerToDatabase();


        }



        private void SaveSchedulerToDatabase()
        {
            var context = (SchedulerSettings)((ScriptSchedulerViewModel)DataContext).Settings;
            var res = Serializer.Serialize(context);
            string connectionString = "Server=85.92.146.196;port=5432;Database=bodyview3;UserID=postgres;Password=Banek12";
            string insertQuery = "INSERT INTO scriptsschedule(scriptid ,schedule ,schedulename) VALUES (@scriptid, @schedule,@schedulename)";
            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {

                NpgsqlCommand commandInsert = new NpgsqlCommand(insertQuery, connection);
                // task name
                commandInsert.Parameters.Add("@scriptid", context.ScriptId);

                //// script name
                commandInsert.Parameters.Add("@schedule", res);

                //// 
                commandInsert.Parameters.Add("@schedulename", context.TaskName);


                try
                {
                    connection.Open();
                    commandInsert.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

        }








        private void Synchronize()
        {
            string connectionString = "Server=85.92.146.196;port=5432;Database=bodyview3;UserID=postgres;Password=Banek12";
            string selectQuery = "select * from scriptsschedule";
            var listOfschedules = new List<string>();
            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {

                connection.Open();
                NpgsqlCommand commandSelect = new NpgsqlCommand(selectQuery, connection);

                // Execute the query and obtain a result set
                NpgsqlDataReader dr = commandSelect.ExecuteReader();

                // Output rows
                while (dr.Read())
                {

                    listOfschedules.Add(dr["schedule"].ToString());
                }
            }
            foreach (var schedule in listOfschedules)
            {

                //var schedulerData = (SchedulerSettings)DataContext;
                var schedulerData = Serializer.Deserialize<SchedulerSettings>(schedule);
                // Connect to the computer "REMOTE" using credentials
                // TaskService ts = new TaskService("REMOTE", "myusername", "MYDOMAIN", "mypassword");

                using (TaskService ts = new TaskService())
                {
                    Task rt = ts.GetTask(schedulerData.TaskName);
                    {
                        if (rt != null && rt.Definition.Triggers.Count > 0)
                        {
                            ts.RootFolder.DeleteTask(schedulerData.TaskName);
                            CreateNewTask(ts, schedulerData);
                            //CompareAndUpdate(rt, schedulerData);
                        }
                        else
                        {
                            CreateNewTask(ts, schedulerData);

                        }
                    }

                }


            }

        }

        private void CreateNewTask(TaskService ts, SchedulerSettings schedulerData)
        {
            Microsoft.Win32.TaskScheduler.Trigger trigger = null;

            // create a new task definition and assign properties
            TaskDefinition td = ts.NewTask();
            td.RegistrationInfo.Description = "does something";

            // create a trigger 
            if (schedulerData.OneTimeChecked)
            {
                trigger = td.Triggers.Add(new TimeTrigger
                {
                    RandomDelay = schedulerData.DelayTaskForUpToValue
                });
            }

            else if (schedulerData.DailyChecked)
            {
                trigger = td.Triggers.Add(new DailyTrigger
                {
                    DaysInterval = schedulerData.DailyCheckedValue,
                    RandomDelay = schedulerData.DelayTaskForUpToValue
                });
            }
            else if (schedulerData.WeeklyCheked)
            {
                trigger = td.Triggers.Add(new WeeklyTrigger
                {
                    WeeksInterval = schedulerData.WeeklySettings.WeeklyChekedValue,
                    RandomDelay = schedulerData.DelayTaskForUpToValue,
                    DaysOfWeek = (DaysOfTheWeek)((schedulerData.WeeklySettings.Monday ? (int)DaysOfTheWeek.Monday : 0)
                                                | (schedulerData.WeeklySettings.Tuesday ? (int)DaysOfTheWeek.Tuesday : 0)
                                                | (schedulerData.WeeklySettings.Wednesday ? (int)DaysOfTheWeek.Wednesday : 0)
                                                | (schedulerData.WeeklySettings.Thursday ? (int)DaysOfTheWeek.Thursday : 0)
                                                | (schedulerData.WeeklySettings.Friday ? (int)DaysOfTheWeek.Friday : 0)
                                                | (schedulerData.WeeklySettings.Saturday ? (int)DaysOfTheWeek.Saturday : 0)
                                                | (schedulerData.WeeklySettings.Sunday ? (int)DaysOfTheWeek.Sunday : 0))
                });

            }

            trigger.StartBoundary = new DateTime(schedulerData.TaskStartDate.Year, schedulerData.TaskStartDate.Month, schedulerData.TaskStartDate.Day,
                                                schedulerData.TaskStartTime.Hour, schedulerData.TaskStartTime.Minute, schedulerData.TaskStartTime.Second);
            trigger.Repetition.Interval = schedulerData.RepateTaskEveryValue;
            trigger.Repetition.Duration = schedulerData.ForDurationOf;
            trigger.ExecutionTimeLimit = schedulerData.StopTaskIfItRunsLongerThanvalue;
            trigger.EndBoundary = new DateTime(schedulerData.ExpireTaskStartDate.Year, schedulerData.ExpireTaskStartDate.Month, schedulerData.ExpireTaskStartDate.Day,
                                               schedulerData.ExpireTaskStartDate.Hour, schedulerData.ExpireTaskStartDate.Minute, schedulerData.TaskStartTime.Second);

            // register the task in the root folder
            td.Actions.Add(new ExecAction("notepad.exe", "c:\\test.log", null));
            //ts.RootFolder.CreateFolder
            //ts.GetFolder("Navitas").GetFolder("ScriptModule").RegisterTaskDefinition(schedulerData.TaskName, td);


        }


        private static void CompareAndUpdate(Task rt, SchedulerSettings schedulerData)
        {

        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {

        }








    }
}
