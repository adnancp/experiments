﻿using System.Linq;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace WpfApplication1.ViewModels
{
    class ScriptSchedulerViewModel : INotifyPropertyChanged
    {
        public ScriptSchedulerViewModel()
        {
            _scripts = new ObservableCollection<ScriptItem>();
        }

        private SchedulerSettings _settings;
        public SchedulerSettings Settings
        {
            get { return _settings; }
            set { _settings = value; OnPropertyChanaged("Settings"); }
        }

        private ObservableCollection<ScriptItem> _scripts;
        public ObservableCollection<ScriptItem> Scripts
        {
            get { return _scripts; }
            private set { _scripts = value; OnPropertyChanaged("Scripts"); }
        }

        public ScriptItem GetSelectedScriptItem()
        {
            return Scripts.FirstOrDefault(i => i.Id == Settings.ScriptId);
        }

        private void OnPropertyChanaged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
